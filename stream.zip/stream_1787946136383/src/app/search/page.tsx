'use client';
import React, { useState, useEffect, useCallback, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import AppImage from '@/components/ui/AppImage';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useAuth } from '@/contexts/AuthContext';
import { userListsService } from '@/lib/services/userListsService';
import {
  getTrendingMovies,
  getTrendingShows,
  searchMovies,
  searchTVShows,
  TMDBMovie,
  TMDBShow,
  TMDBSearchResult,
} from '@/lib/services/tmdbService';
import { MagnifyingGlassIcon, AdjustmentsHorizontalIcon, XMarkIcon } from '@heroicons/react/24/outline';

// ─── Types ────────────────────────────────────────────────────────────────────

type MediaTab = 'all' | 'movies' | 'shows';

interface CatalogItem {
  id: number;
  title: string;
  mediaType: 'movie' | 'tv';
  genre: string;
  year: string;
  rating: string;
  img: string;
  alt: string;
  overview: string;
  color: string;
}

// ─── Constants ────────────────────────────────────────────────────────────────

const GENRES = [
  'All', 'Action', 'Adventure', 'Animation', 'Comedy', 'Crime',
  'Drama', 'Fantasy', 'Horror', 'Mystery', 'Romance', 'Sci-Fi',
  'Thriller', 'War', 'Western', 'Family', 'History', 'Music',
];

const YEARS = ['All', '2025', '2024', '2023', '2022', '2021', '2020', '2019', '2018', '2017', '2016'];

const RATINGS = [
  { label: 'All', min: 0 },
  { label: '9+', min: 9 },
  { label: '8+', min: 8 },
  { label: '7+', min: 7 },
  { label: '6+', min: 6 },
];

const ACCENT_COLORS = ['#7B2FFF', '#FF4B6E', '#00E5FF', '#FFB800'];
function getColor(id: number) { return ACCENT_COLORS[id % ACCENT_COLORS.length]; }

// ─── Card Actions ─────────────────────────────────────────────────────────────

interface CardActionsProps {
  mediaId: string;
  mediaType: 'movie' | 'tv';
  title: string;
  posterUrl: string;
  genre: string;
  year: string;
  rating: string;
}

const CardActions: React.FC<CardActionsProps> = ({ mediaId, mediaType, title, posterUrl, genre, year, rating }) => {
  const { user } = useAuth();
  const router = useRouter();
  const [isFav, setIsFav] = useState(false);
  const [isWatchlist, setIsWatchlist] = useState(false);
  const [favLoading, setFavLoading] = useState(false);
  const [watchLoading, setWatchLoading] = useState(false);

  const checkStatus = useCallback(async () => {
    if (!user) return;
    try {
      const [fav, watch] = await Promise.all([
        userListsService.isFavorite(user.id, mediaId, mediaType),
        userListsService.isInWatchlist(user.id, mediaId, mediaType),
      ]);
      setIsFav(fav);
      setIsWatchlist(watch);
    } catch { /* silent */ }
  }, [user, mediaId, mediaType]);

  useEffect(() => { checkStatus(); }, [checkStatus]);

  const handleFavorite = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) { router.push('/login'); return; }
    setFavLoading(true);
    try {
      if (isFav) {
        await userListsService.removeFavorite(user.id, mediaId, mediaType);
        setIsFav(false);
      } else {
        await userListsService.addFavorite(user.id, { mediaId, mediaType, title, posterUrl, genre, year, rating });
        setIsFav(true);
      }
    } catch { /* silent */ } finally { setFavLoading(false); }
  };

  const handleWatchlist = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) { router.push('/login'); return; }
    setWatchLoading(true);
    try {
      if (isWatchlist) {
        await userListsService.removeFromWatchlist(user.id, mediaId, mediaType);
        setIsWatchlist(false);
      } else {
        await userListsService.addToWatchlist(user.id, { mediaId, mediaType, title, posterUrl, genre, year, rating });
        setIsWatchlist(true);
      }
    } catch { /* silent */ } finally { setWatchLoading(false); }
  };

  return (
    <div className="absolute top-2 right-2 flex flex-col gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
      <button
        onClick={handleFavorite}
        disabled={favLoading}
        title={isFav ? 'Remove from Favorites' : 'Add to Favorites'}
        className="w-7 h-7 rounded-full flex items-center justify-center text-xs transition-all duration-150"
        style={{
          background: isFav ? 'rgba(255,75,110,0.9)' : 'rgba(0,0,0,0.7)',
          border: '1px solid rgba(255,75,110,0.5)',
          color: isFav ? '#fff' : '#FF4B6E',
          backdropFilter: 'blur(8px)',
        }}
      >
        {favLoading ? '·' : '❤'}
      </button>
      <button
        onClick={handleWatchlist}
        disabled={watchLoading}
        title={isWatchlist ? 'Remove from Watchlist' : 'Add to Watchlist'}
        className="w-7 h-7 rounded-full flex items-center justify-center text-xs transition-all duration-150"
        style={{
          background: isWatchlist ? 'rgba(0,229,255,0.9)' : 'rgba(0,0,0,0.7)',
          border: '1px solid rgba(0,229,255,0.5)',
          color: isWatchlist ? '#0D0D0D' : '#00E5FF',
          backdropFilter: 'blur(8px)',
        }}
      >
        {watchLoading ? '·' : '🔖'}
      </button>
    </div>
  );
};

// ─── Media Card ───────────────────────────────────────────────────────────────

interface MediaCardProps {
  item: CatalogItem;
}

const MediaCard: React.FC<MediaCardProps> = ({ item }) => {
  const router = useRouter();
  return (
    <div
      className="relative group cursor-pointer rounded-xl overflow-hidden flex-shrink-0"
      style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}
      onClick={() => router.push(`/media/${item.mediaType}/${item.id}`)}
    >
      <div className="relative" style={{ paddingBottom: '150%' }}>
        <AppImage src={item.img} alt={item.alt} fill className="object-cover" />
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, transparent 40%, rgba(0,0,0,0.97) 100%)' }} />

        {/* Genre badge */}
        <div
          className="absolute top-2 left-2 px-2 py-0.5 rounded-full text-xs font-bold"
          style={{
            background: `${item.color}33`,
            border: `1px solid ${item.color}55`,
            color: item.color,
            fontFamily: 'JetBrains Mono, monospace',
            fontSize: '10px',
          }}
        >
          {item.genre}
        </div>

        {/* Media type badge */}
        <div
          className="absolute top-2 right-2 px-2 py-0.5 rounded-full text-xs font-bold opacity-0 group-hover:opacity-100 transition-opacity"
          style={{
            background: item.mediaType === 'movie' ? 'rgba(123,47,255,0.8)' : 'rgba(0,229,255,0.15)',
            border: `1px solid ${item.mediaType === 'movie' ? 'rgba(123,47,255,0.6)' : 'rgba(0,229,255,0.4)'}`,
            color: item.mediaType === 'movie' ? '#fff' : '#00E5FF',
            fontSize: '9px',
            fontFamily: 'JetBrains Mono, monospace',
          }}
        >
          {item.mediaType === 'movie' ? '🎬 Film' : '📺 Series'}
        </div>

        <CardActions
          mediaId={String(item.id)}
          mediaType={item.mediaType}
          title={item.title}
          posterUrl={item.img}
          genre={item.genre}
          year={item.year}
          rating={item.rating}
        />

        <div className="absolute bottom-0 left-0 right-0 p-3">
          <p className="text-sm font-bold text-white leading-tight mb-1 line-clamp-2">{item.title}</p>
          <div className="flex items-center justify-between">
            <span style={{ fontSize: '11px', color: 'rgba(255,255,255,0.45)' }}>{item.year}</span>
            <span style={{ fontSize: '11px', color: '#FFB800', fontFamily: 'JetBrains Mono, monospace' }}>★ {item.rating}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

// ─── Filter Pill ──────────────────────────────────────────────────────────────

interface FilterPillProps {
  label: string;
  active: boolean;
  onClick: () => void;
}

const FilterPill: React.FC<FilterPillProps> = ({ label, active, onClick }) => (
  <button
    onClick={onClick}
    className="px-3 py-1.5 rounded-full text-xs font-semibold transition-all duration-200 whitespace-nowrap"
    style={{
      background: active ? 'linear-gradient(135deg, #7B2FFF, #00E5FF)' : 'rgba(255,255,255,0.06)',
      border: active ? 'none' : '1px solid rgba(255,255,255,0.1)',
      color: active ? '#fff' : 'rgba(240,240,240,0.55)',
      fontFamily: 'JetBrains Mono, monospace',
      boxShadow: active ? '0 0 16px rgba(123,47,255,0.35)' : 'none',
    }}
  >
    {label}
  </button>
);

// ─── Main Search Page Content ─────────────────────────────────────────────────

function SearchPageContent() {
  const searchParams = useSearchParams();
  const router = useRouter();

  const initialQuery = searchParams.get('q') || '';

  const [query, setQuery] = useState(initialQuery);
  const [inputValue, setInputValue] = useState(initialQuery);
  const [activeTab, setActiveTab] = useState<MediaTab>('all');
  const [selectedGenre, setSelectedGenre] = useState('All');
  const [selectedYear, setSelectedYear] = useState('All');
  const [selectedRating, setSelectedRating] = useState(0);
  const [showFilters, setShowFilters] = useState(false);

  const [catalog, setCatalog] = useState<CatalogItem[]>([]);
  const [searchResults, setSearchResults] = useState<CatalogItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);

  // Load full catalog on mount
  useEffect(() => {
    async function loadCatalog() {
      setLoading(true);
      try {
        const [movies, shows] = await Promise.all([getTrendingMovies(), getTrendingShows()]);
        const combined: CatalogItem[] = [
          ...movies.map((m: TMDBMovie) => ({
            id: m.id,
            title: m.title,
            mediaType: 'movie' as const,
            genre: m.genre,
            year: m.year,
            rating: m.rating,
            img: m.img,
            alt: m.alt,
            overview: m.overview,
            color: m.color,
          })),
          ...shows.map((s: TMDBShow) => ({
            id: s.id,
            title: s.title,
            mediaType: 'tv' as const,
            genre: s.genre,
            year: s.year,
            rating: s.rating,
            img: s.img,
            alt: s.alt,
            overview: s.overview,
            color: s.color,
          })),
        ];
        setCatalog(combined);
      } catch { /* silent */ } finally {
        setLoading(false);
      }
    }
    loadCatalog();
  }, []);

  // Search when query changes
  useEffect(() => {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }
    async function doSearch() {
      setSearching(true);
      try {
        const [movies, shows] = await Promise.all([
          searchMovies(query),
          searchTVShows(query),
        ]);
        const combined: CatalogItem[] = [
          ...movies.map((m: TMDBSearchResult) => ({
            id: m.id,
            title: m.title,
            mediaType: 'movie' as const,
            genre: m.genre,
            year: m.year,
            rating: m.rating,
            img: m.img,
            alt: m.alt,
            overview: m.overview,
            color: getColor(m.id),
          })),
          ...shows.map((s: TMDBSearchResult) => ({
            id: s.id,
            title: s.title,
            mediaType: 'tv' as const,
            genre: s.genre,
            year: s.year,
            rating: s.rating,
            img: s.img,
            alt: s.alt,
            overview: s.overview,
            color: getColor(s.id),
          })),
        ];
        setSearchResults(combined);
      } catch { /* silent */ } finally {
        setSearching(false);
      }
    }
    doSearch();
  }, [query]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = inputValue.trim();
    setQuery(trimmed);
    if (trimmed) {
      router.replace(`/search?q=${encodeURIComponent(trimmed)}`, { scroll: false });
    } else {
      router.replace('/search', { scroll: false });
    }
  };

  const clearSearch = () => {
    setInputValue('');
    setQuery('');
    router.replace('/search', { scroll: false });
  };

  const resetFilters = () => {
    setSelectedGenre('All');
    setSelectedYear('All');
    setSelectedRating(0);
    setActiveTab('all');
  };

  const hasActiveFilters = selectedGenre !== 'All' || selectedYear !== 'All' || selectedRating > 0 || activeTab !== 'all';

  // Source: search results if query present, else full catalog
  const source = query.trim() ? searchResults : catalog;

  // Apply filters
  const filtered = source.filter((item) => {
    if (activeTab === 'movies' && item.mediaType !== 'movie') return false;
    if (activeTab === 'shows' && item.mediaType !== 'tv') return false;
    if (selectedGenre !== 'All' && !item.genre.toLowerCase().includes(selectedGenre.toLowerCase())) return false;
    if (selectedYear !== 'All' && item.year !== selectedYear) return false;
    if (selectedRating > 0 && parseFloat(item.rating) < selectedRating) return false;
    return true;
  });

  const isLoading = loading || searching;

  return (
    <div className="min-h-screen" style={{ background: '#0D0D0D', color: '#F0F0F0' }}>
      <Header />

      <main className="pt-28 pb-20">
        <div className="max-w-7xl mx-auto px-6">

          {/* Page heading */}
          <div className="mb-10">
            <p className="text-xs font-bold uppercase tracking-widest mb-2" style={{ color: '#7B2FFF', fontFamily: 'JetBrains Mono, monospace' }}>
              Catalog
            </p>
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight" style={{ fontFamily: 'JetBrains Mono, monospace' }}>
              {query ? (
                <>Results for <span style={{ background: 'linear-gradient(135deg, #7B2FFF, #00E5FF)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>"{query}"</span></>
              ) : (
                <>Full <span style={{ background: 'linear-gradient(135deg, #7B2FFF, #00E5FF)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Catalog</span></>
              )}
            </h1>
            {!isLoading && (
              <p className="mt-2 text-sm" style={{ color: 'rgba(240,240,240,0.4)', fontFamily: 'JetBrains Mono, monospace' }}>
                {filtered.length} title{filtered.length !== 1 ? 's' : ''} found
              </p>
            )}
          </div>

          {/* Search bar */}
          <form onSubmit={handleSearchSubmit} className="mb-8">
            <div
              className="flex items-center rounded-2xl overflow-hidden"
              style={{
                background: 'rgba(255,255,255,0.05)',
                border: '1px solid rgba(255,255,255,0.1)',
                backdropFilter: 'blur(12px)',
              }}
            >
              <MagnifyingGlassIcon className="w-5 h-5 ml-4 flex-shrink-0" style={{ color: '#7B2FFF' }} />
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Search movies, shows, genres..."
                className="flex-1 bg-transparent px-4 py-4 text-base outline-none"
                style={{ color: '#F0F0F0', fontFamily: 'JetBrains Mono, monospace' }}
              />
              {inputValue && (
                <button
                  type="button"
                  onClick={clearSearch}
                  className="p-2 mr-1 rounded-full transition-colors"
                  style={{ color: 'rgba(240,240,240,0.4)' }}
                  onMouseEnter={(e) => (e.currentTarget.style.color = '#F0F0F0')}
                  onMouseLeave={(e) => (e.currentTarget.style.color = 'rgba(240,240,240,0.4)')}
                >
                  <XMarkIcon className="w-4 h-4" />
                </button>
              )}
              <button
                type="submit"
                className="m-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200"
                style={{
                  background: 'linear-gradient(135deg, #7B2FFF, #9B5FFF)',
                  color: '#fff',
                  fontFamily: 'JetBrains Mono, monospace',
                  boxShadow: '0 0 16px rgba(123,47,255,0.4)',
                }}
              >
                Search
              </button>
            </div>
          </form>

          {/* Filter bar */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              {/* Tab switcher */}
              <div className="flex gap-1 p-1 rounded-xl" style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}>
                {(['all', 'movies', 'shows'] as MediaTab[]).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className="px-4 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all duration-200"
                    style={{
                      background: activeTab === tab ? 'rgba(123,47,255,0.8)' : 'transparent',
                      color: activeTab === tab ? '#fff' : 'rgba(240,240,240,0.5)',
                      fontFamily: 'JetBrains Mono, monospace',
                    }}
                  >
                    {tab === 'all' ? 'All' : tab === 'movies' ? '🎬 Films' : '📺 Series'}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-3">
                {hasActiveFilters && (
                  <button
                    onClick={resetFilters}
                    className="text-xs transition-colors"
                    style={{ color: 'rgba(240,240,240,0.4)', fontFamily: 'JetBrains Mono, monospace' }}
                    onMouseEnter={(e) => (e.currentTarget.style.color = '#FF4B6E')}
                    onMouseLeave={(e) => (e.currentTarget.style.color = 'rgba(240,240,240,0.4)')}
                  >
                    Clear filters
                  </button>
                )}
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all duration-200"
                  style={{
                    background: showFilters ? 'rgba(0,229,255,0.12)' : 'rgba(255,255,255,0.06)',
                    border: `1px solid ${showFilters ? 'rgba(0,229,255,0.4)' : 'rgba(255,255,255,0.1)'}`,
                    color: showFilters ? '#00E5FF' : 'rgba(240,240,240,0.55)',
                    fontFamily: 'JetBrains Mono, monospace',
                  }}
                >
                  <AdjustmentsHorizontalIcon className="w-4 h-4" />
                  Filters {hasActiveFilters && <span className="w-1.5 h-1.5 rounded-full bg-current inline-block" />}
                </button>
              </div>
            </div>

            {/* Expandable filter panels */}
            {showFilters && (
              <div
                className="rounded-2xl p-5 space-y-5"
                style={{
                  background: 'rgba(255,255,255,0.03)',
                  border: '1px solid rgba(255,255,255,0.08)',
                  backdropFilter: 'blur(12px)',
                }}
              >
                {/* Genre */}
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest mb-3" style={{ color: 'rgba(240,240,240,0.35)', fontFamily: 'JetBrains Mono, monospace' }}>
                    Genre
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {GENRES.map((g) => (
                      <FilterPill
                        key={g}
                        label={g}
                        active={selectedGenre === g}
                        onClick={() => setSelectedGenre(g)}
                      />
                    ))}
                  </div>
                </div>

                {/* Year */}
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest mb-3" style={{ color: 'rgba(240,240,240,0.35)', fontFamily: 'JetBrains Mono, monospace' }}>
                    Year
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {YEARS.map((y) => (
                      <FilterPill
                        key={y}
                        label={y}
                        active={selectedYear === y}
                        onClick={() => setSelectedYear(y)}
                      />
                    ))}
                  </div>
                </div>

                {/* Rating */}
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest mb-3" style={{ color: 'rgba(240,240,240,0.35)', fontFamily: 'JetBrains Mono, monospace' }}>
                    Min Rating
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {RATINGS.map((r) => (
                      <FilterPill
                        key={r.label}
                        label={r.label === 'All' ? 'Any Rating' : `★ ${r.label}`}
                        active={selectedRating === r.min}
                        onClick={() => setSelectedRating(r.min)}
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Results grid */}
          {isLoading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {[...Array(12)].map((_, i) => (
                <div
                  key={i}
                  className="rounded-xl animate-pulse"
                  style={{ paddingBottom: '150%', background: 'rgba(255,255,255,0.05)' }}
                />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-32 text-center">
              <div className="text-6xl mb-6">🎬</div>
              <h3 className="text-xl font-bold mb-2" style={{ fontFamily: 'JetBrains Mono, monospace' }}>
                No results found
              </h3>
              <p className="text-sm mb-6" style={{ color: 'rgba(240,240,240,0.4)' }}>
                {query ? `No titles match "${query}" with the current filters.` : 'No titles match the current filters.'}
              </p>
              <button
                onClick={resetFilters}
                className="px-5 py-2.5 rounded-full text-sm font-semibold transition-all duration-200"
                style={{
                  background: 'rgba(123,47,255,0.2)',
                  border: '1px solid rgba(123,47,255,0.5)',
                  color: '#9B5FFF',
                  fontFamily: 'JetBrains Mono, monospace',
                }}
              >
                Clear all filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {filtered.map((item) => (
                <MediaCard key={`${item.mediaType}-${item.id}`} item={item} />
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}

// ─── Page Export (wrapped in Suspense for useSearchParams) ────────────────────

export default function SearchPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center" style={{ background: '#0D0D0D' }}>
        <div className="text-center">
          <div className="w-8 h-8 rounded-full border-2 border-t-transparent animate-spin mx-auto mb-4" style={{ borderColor: '#7B2FFF', borderTopColor: 'transparent' }} />
          <p className="text-sm" style={{ color: 'rgba(240,240,240,0.4)', fontFamily: 'JetBrains Mono, monospace' }}>Loading catalog...</p>
        </div>
      </div>
    }>
      <SearchPageContent />
    </Suspense>
  );
}
